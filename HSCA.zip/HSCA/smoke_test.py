"""Minimal smoke test for HSCA.

Checks:
  1. HSCANetwork forward returns (pred, raw_scores_stk[N,N], debug, attn_stk[N,N])
     for each universe (sp500 -> M=1, csi300 dual -> M=2, csi300 single -> M=1, csi800 -> M=2).
  2. Eq. 4 mean-pool: z = A.mean(0); state_gate input dim is d (not 2d).
  3. Eq. 3 single MLP: state_encoder has one mlp_state, not two parallel encoders.
  4. Structural Hinge Loss assembles correctly and uses gamma = 0.5.
  5. No top-k attribute (set_sparsity_ratio / current_ratio / keep_ratio) remains.
"""
import sys
import torch

sys.path.insert(0, '.')

from hsca_model import (
    HSCANetwork, HSCAModel,
    StateConditionedHeteroAttention,
    StateAnchorEncoder, AsymmetricDualStream,
)
from base_model import HINGE_MARGIN, SequenceModel


def fake_batch(N, L, F_s, universe):
    # x has shape [N, L, F_s + 63]; trailing 63 dims = 3 broad indices * 21 macro dims
    return torch.randn(N, L, F_s + 63)


def test_forward(universe, N=50, L=8, F_s=158, d_model=64, use_single_index=False):
    net = HSCANetwork(d_feat=F_s, d_model=d_model, universe=universe,
                      use_single_index=use_single_index, nhead=4)
    expected_M = (1 if universe == 'sp500'
                  else (1 if (universe == 'csi300' and use_single_index) else 2))
    assert net.num_anchors == expected_M, f"{universe}: M mismatch ({net.num_anchors} vs {expected_M})"

    x = fake_batch(N, L, F_s, universe)
    pred, raw_scores_stk, debug, attn_stk = net(x)

    assert pred.shape == (N,), f"pred shape {pred.shape}"
    assert raw_scores_stk.shape == (N, N), f"raw_scores_stk shape {raw_scores_stk.shape}"
    assert attn_stk.shape == (N, N), f"attn_stk shape {attn_stk.shape}"
    assert 'alpha_gate_mean' in debug
    print(f"  [{universe} M={expected_M} single={use_single_index}] forward OK, "
          f"pred[N={pred.shape[0]}], S_stk[{raw_scores_stk.shape}]")


def test_eq3_single_mlp():
    enc = StateAnchorEncoder(state_dim=42, d_model=64, num_anchors=2)
    # Should have one mlp_state (a Sequential), not two parallel encoders.
    assert hasattr(enc, 'mlp_state')
    assert not hasattr(enc, 'encoder_primary')
    assert not hasattr(enc, 'encoder_secondary')
    A = enc(torch.randn(42))
    assert A.shape == (2, 64), f"A shape {A.shape}"
    print(f"  Eq. 3 single MLP: state_dim=42 -> A[{A.shape}]")


def test_eq4_pool_and_gate_dim():
    # State Gate must be Linear(d, d), not Linear(2d, d).
    attn = StateConditionedHeteroAttention(d_model=64, nhead=4)
    first_linear = attn.state_gate[0]  # Sequential(Linear, Sigmoid)
    assert first_linear.in_features == 64, f"state_gate in_features {first_linear.in_features}"
    assert first_linear.out_features == 64, f"state_gate out_features {first_linear.out_features}"
    print(f"  Eq. 4-5: state_gate is Linear({first_linear.in_features} -> {first_linear.out_features})")

    # Verify z = mean(A) inside the dual stream
    ds = AsymmetricDualStream(d_feat=158, d_model=64, state_dim=42, num_anchors=2)
    h, A, z = ds(torch.randn(10, 8, 158), torch.randn(42))
    assert torch.allclose(z, A.mean(dim=0))
    print(f"  Eq. 4: z = A.mean(dim=0) verified (A[{A.shape}], z[{z.shape}])")


def test_no_topk():
    net = HSCANetwork(d_feat=158, d_model=64, universe='csi300', use_single_index=False)
    # None of the top-k machinery should survive.
    assert not hasattr(net, 'set_sparsity_ratio')
    assert not hasattr(net, 'current_ratio')
    # Inspect attention forward signature
    import inspect
    sig = inspect.signature(net.attention.forward)
    assert 'keep_ratio' not in sig.parameters
    print(f"  Top-k removed: set_sparsity_ratio/current_ratio/keep_ratio absent")


def test_gamma_05():
    assert HINGE_MARGIN == 0.5, f"HINGE_MARGIN = {HINGE_MARGIN}, expected 0.5"
    print(f"  HINGE_MARGIN = {HINGE_MARGIN} (paper gamma)")


def test_structural_loss():
    # Build a SequenceModel-like instance just to call _structural_loss
    class StubModel:
        pass
    sm = SequenceModel.__new__(SequenceModel)
    sm.use_hinge_loss = True
    # On a [N, N] block with perfectly aligned signs, hinge loss should be 0
    # once raw scores exceed the margin in the correct direction.
    N = 20
    y = torch.randn(N)
    # Construct raw_scores = sign(y_i*y_j) * 1.0 so T*S = 1.0 > gamma=0.5 -> hinge=0
    T = torch.sign(y.view(-1, 1) @ y.view(1, -1))
    raw = T * 1.0
    L = sm._structural_loss(raw, y)
    assert L.item() < 1e-6, f"Aligned case should be zero loss, got {L.item()}"
    print(f"  L_struct aligned case: {L.item():.4e} (zero as expected)")

    # Flipped signs: T*S = -1.0 < gamma=0.5 -> hinge = relu(0.5 - (-1.0)) = 1.5
    # Diagonal entries have T = +1 (self-sign x self-sign), S = -1, so hinge = 1.5
    # Off-diagonals: T = -sign(...)?  Actually flipping S gives T*S = -1 everywhere.
    raw_flip = -T * 1.0
    L_flip = sm._structural_loss(raw_flip, y)
    # Expected: mean of max(0, 0.5 - (-1.0)) = 1.5
    assert abs(L_flip.item() - 1.5) < 1e-3, f"Flipped case expected 1.5, got {L_flip.item()}"
    print(f"  L_struct flipped case: {L_flip.item():.4f} (expected ~1.5)")


def test_full_loss_path():
    # End-to-end: build a HSCAModel-equivalent (without optimizer wiring) and
    # confirm raw_scores_stk feeds cleanly into the structural loss.
    net = HSCANetwork(d_feat=158, d_model=64, universe='sp500')
    x = torch.randn(30, 8, 158 + 63)
    pred, raw_scores_stk, _, _ = net(x)

    sm = SequenceModel.__new__(SequenceModel)
    sm.use_hinge_loss = True
    y = torch.randn(30)
    L = sm._structural_loss(raw_scores_stk, y)
    assert torch.isfinite(L), f"non-finite L: {L}"
    print(f"  End-to-end SP500 (M=1): pred[{pred.shape}], L_struct={L.item():.4f}")

    # Backprop sanity
    L.backward()
    has_grad = any(p.grad is not None and p.grad.abs().sum() > 0 for p in net.parameters())
    assert has_grad, "no gradient flowed through L_struct"
    print(f"  Backprop OK, gradients flow into attention parameters")


if __name__ == '__main__':
    print("== Forward shape tests ==")
    test_forward('sp500')
    test_forward('csi300', use_single_index=False)  # M=2
    test_forward('csi300', use_single_index=True)   # M=1
    test_forward('csi800')

    print("\n== Equation alignment ==")
    test_eq3_single_mlp()
    test_eq4_pool_and_gate_dim()
    test_gamma_05()

    print("\n== Top-k removal ==")
    test_no_topk()

    print("\n== Structural Hinge Loss ==")
    test_structural_loss()
    test_full_loss_path()

    print("\nAll smoke tests passed.")
